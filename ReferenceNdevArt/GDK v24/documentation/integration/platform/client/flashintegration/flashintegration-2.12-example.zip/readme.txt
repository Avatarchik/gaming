# Integration Example README

This example shows the basic functionality required to load a Flash game from the Amaya platform.


# Contents

IntegrationExample.as: The document class containing the code for the example.
IntegrationExample.fla: The graphics for the example. Also links the IntegrationExample.as class as the document class.
IntegrationExample.swf: A pre-compiled version of the example.
IntegrationExample.html: THe HTML file that loads the IntegrationExample.swf.


# Running the Example

In order to function properly, the example must be run from a webserver, *not* from the local file-system. Any webserver
should work fine. This is example was developed using a version of Apache Tomcat.

To run from Tomcat, download and unzip the webserver. Create a directory in Tomcat's "webapps" directory and copy the
"IntegrationExample.swf" and "IntegrationExample.html" files into it. Start Tomcat by running the "bin/startup.bat" file.
Once started, go to "http://localhost:8080/<your webapp directory>/IntegrationExample.html".


# Using the Example

On startup, the example application will load a game from the "http://opal.chartwelltech.com/" server. This is an
externally accessible instance of the CGS.

The right side of the application contains an output field that will print
out the communication between the host SWF (the IntegrationExample.swf) and the framework/game. Items preceded by "<--"
represent events being sent from the framework to the host. Items preceded by "-->" represent events being sent to the
framework from the host.

Incoming events are defined in the IntegrationExample.as class. Not all events are being listened for. Instead a selection
of the most commonly used events have listeners defined.

Across the bottom of the app, a set of buttons are presented which each send a command to the framework. When pressed,
the handler in IntegrationExample.as will send the appropriate command. Again, not all commands are represented here,
only the most commonly used commands.